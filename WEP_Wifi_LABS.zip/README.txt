Create wifi VMs using build scripts provided on Ubuntu templates
Build scripts will create multiple LXD containers.
Attacker LXC container will have SSH enabled and forwarded via socat on main host. So SSH directly into attacker container is possible from external VMs.


After building the VMs test the corresponding WEP  attack and make sure it is possible from start to finish per each section
