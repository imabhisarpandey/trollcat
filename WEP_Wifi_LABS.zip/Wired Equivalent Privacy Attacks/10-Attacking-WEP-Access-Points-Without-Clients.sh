echo "[+] Configuring hostname"
hostnamectl set-hostname WEP
cat << EOF > /etc/hosts
127.0.0.1 localhost
127.0.0.1 WEP
EOF

# Install dependancies
apt install hostapd python3 python3-pip python3-scapy wpasupplicant wireless-tools net-tools lxc python3-lxc iw socat dnsmasq ifupdown arping -y

# Delete resolv.conf
rm -rf /etc/resolve.conf

# create resolv.conf
echo "nameserver 1.1.1.1" > /etc/resolv.conf
chmod 0644 /etc/resolv.conf
chown root:root /etc/resolv.conf

# Add mac80211_hwsim to /etc/modules
echo mac80211_hwsim >> /etc/modules

# Add options to modules
echo 'options mac80211_hwsim radios=2' >> /etc/modprobe.d/hwsim.conf

# REBOOT or following (create temp radios)
modprobe mac80211_hwsim radios=2

# Add hostapd file (Note to HTB: If youd like on this simulation, you can add challenge by making the WEP key 128-bits instead)
cat <<EOF > /etc/hostapd/hostapd.conf
interface=wlan0
driver=nl80211
ssid=HacktheWEPWifi
channel=1
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wep_default_key=0
wep_key0=1A2B3C4D5E
bssid=36:8f:2b:5e:35:05
EOF

chmod 0644 /etc/hostapd/hostapd.conf
chown root:root /etc/hostapd/hostapd.conf

chown -R root:root /etc/hostapd
chmod -R 0644 /etc/hostapd

## Create Containers
lxc-create -t download -n attica2 -- --dist ubuntu --release jammy --arch amd64

# COnfigure IP forwarding and stuff
sysctl net.ipv4.ip_forward=1

## Configure DHCP server (Note to HTB, in some simulations we may need to expand on this one, since they will require some network layer operations)
cat <<EOF > /etc/dnsmasq.conf
interface=wlan0
dhcp-range=192.168.1.2,192.168.1.100,255.255.255.0,12h
EOF
chmod 755 /etc/dnsmasq.conf
chown root:root /etc/dnsmasq.conf

## Configure network
cat <<EOF > /etc/network/interfaces
auto wlan0
iface wlan0 inet static
    address 192.168.1.1
    netmask 255.255.255.0
EOF

## Configure network adapters in attica2 container
rm  /var/lib/lxc/attica2/config
cat <<EOF >> /var/lib/lxc/attica2/config
# Distribution configuration
lxc.include = /usr/share/lxc/config/common.conf
lxc.arch = linux64

# Container specific configuration
lxc.rootfs.path = dir:/var/lib/lxc/attica2/rootfs
lxc.uts.name = attica2

# Network configuration
lxc.net.0.type = veth
lxc.net.0.link = lxcbr0
lxc.net.0.flags = up
lxc.net.0.ipv4.address = "10.0.3.3/24"
lxc.net.1.type = phys
lxc.net.1.link = wlan1
lxc.net.1.flags = up
lxc.net.1.name = "wlan0"
lxc.start.delay = 1
EOF

## Autostart container at boot
cat <<EOF >> /etc/lxc/default.conf
lxc.start.auto = 1
EOF

## unmask hostapd
systemctl unmask hostapd
systemctl enable hostapd
systemctl start hostapd

## Start the attica2 Container and configure
lxc-start -n attica2 -d
lxc-attach -n attica2 -e -- sh -c "apt update; apt install -y openssh-server net-tools git wireless-tools aircrack-ng pciutils wpasupplicant reaver;"

## Add user to the container
lxc-attach -n attica2 -- useradd -m wifi
lxc-attach -n attica2 -- chpasswd <<< wifi:wifi
lxc-attach -n attica2 -e -- sh -c "sudo usermod -a -G sudo wifi"
## SSH forward
systemctl disable ssh
systemctl stop ssh
## Create Socat service to forward all SSH trafic to attica2 container
cat <<EOF > /etc/systemd/system/socat-forward.service
[Unit]
Description=Socat Port Forwarding Service
After=network.target

[Service]
ExecStart=/usr/bin/socat TCP-LISTEN:22,bind=0.0.0.0,fork TCP:10.0.3.3:22
Restart=always

[Install]
WantedBy=multi-user.target
EOF
## Install XFCE (Light weight desktop environment) inside WPAtomic container
lxc-attach -n attica2 -e -- sh -c "apt update -y; apt install -y xfce4 xfce4-goodies xrdp; echo 'xfce4-session' > /home/wifi/.xsession"
lxc-attach -n attica2 -e -- sh -c "apt install network-manager-gnome -y"
## Create Socat service to forward all RDP trafic to WPAtomic container
cat <<EOF > /etc/systemd/system/socat-forward-rdp.service
[Unit]
Description=Socat Port Forwarding Service
After=network.target
[Service]
ExecStart=/usr/bin/socat TCP-LISTEN:3389,bind=0.0.0.0,fork TCP:10.0.3.3:3389
Restart=always
[Install]
WantedBy=multi-user.target
EOF

## Set the background to a hack-the-box one
lxc-attach -n attica2 -e -- sh -c "wget https://github.com/ParrotSec/parrot-wallpapers/blob/master/backgrounds/hackthebox-alt.jpg?raw=truehttps://github.com/ParrotSec/parrot-wallpapers/blob/master/backgrounds/hackthebox-alt.jpg?raw=true -O /usr/share/backgrounds/xfce/xfce-verticals.png"
## Set shell to /bin/bash
lxc-attach -n attica2 -e -- sh -c "chsh -s /bin/bash wifi"

systemctl daemon-reload
systemctl restart socat-forward
systemctl restart socat-forward-rdp
systemctl enable dnsmasq
systemctl restart dnsmasq.service
systemctl enable socat-forward
systemctl enable socat-forward-rdp
ifdown wlan0 && ifup wlan0

## Configure Traffic generation service (Used to generate traffic through the host machine to allow attackers to generate real ARP packets)
## Basically flus the neighbor cache and hit a non-existent IP address
cat <<EOF > /opt/traffic.sh
#!/bin/bash
sleep 5
while :; do ip neigh flush all dev wlan0; ping 192.168.1.255 -c 1; sleep 5; done
EOF

chmod +x /opt/traffic.sh
cat <<EOF > /etc/systemd/system/traffic.service
[Unit]
Description=traffic for wireless simulation
After=network.target
[Service]
User=root
WorkingDirectory=/opt
ExecStart=/opt/traffic.sh
[Install]
WantedBy=multi-user.target
EOF

chmod +x /opt/traffic.sh
chmod 700 /etc/systemd/system/traffic.service
sudo systemctl daemon-reload
sudo systemctl start traffic
sudo systemctl enable traffic

## Create the container bridge for traffic generation
brctl addbr client_bridge
ip link set client_bridge up
ifconfig client_bridge 192.168.2.1/24
ip route add 192.168.1.0/24 via 192.168.2.1