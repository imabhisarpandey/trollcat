echo "[+] Configuring hostname"
hostnamectl set-hostname Fragmentation
cat << EOF > /etc/hosts
127.0.0.1 localhost
127.0.0.1 Fragmentation
EOF

# Install dependancies
apt install hostapd wpasupplicant wireless-tools net-tools lxc python3-lxc iw socat dnsmasq ifupdown arping tcpdump -y

# Delete resolv.conf
rm -rf /etc/resolve.conf

# create resolv.conf
echo "nameserver 1.1.1.1" > /etc/resolv.conf
chmod 0644 /etc/resolv.conf
chown root:root /etc/resolv.conf

# Add mac80211_hwsim to /etc/modules
echo mac80211_hwsim >> /etc/modules

# Add options to modules
echo 'options mac80211_hwsim radios=3' >> /etc/modprobe.d/hwsim.conf

# REBOOT or following (create temp radios)
modprobe mac80211_hwsim radios=3

# Add hostapd file (Note to HTB: If youd like on this simulation, you can add challenge by making the WEP key 128-bits instead)
cat <<EOF > /etc/hostapd/hostapd.conf
interface=wlan0
driver=nl80211
ssid=HacktheWEPWifi
channel=1
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wep_default_key=0
wep_key0=1A2B3C4D5E
EOF

chmod 0644 /etc/hostapd/hostapd.conf
chown root:root /etc/hostapd/hostapd.conf

chown -R root:root /etc/hostapd
chmod -R 0644 /etc/hostapd

## Create Containers
lxc-create -t download -n attica -- --dist ubuntu --release jammy --arch amd64
lxc-create -t download -n client -- --dist ubuntu --release jammy --arch amd64

## Configure DHCP server (Note to HTB, in some simulations we may need to expand on this one, since they will require some network layer operations)
cat <<EOF > /etc/dnsmasq.conf
interface=wlan0
dhcp-range=192.168.1.2,192.168.1.100,255.255.255.0,12h
EOF
chmod 755 /etc/dnsmasq.conf
chown root:root /etc/dnsmasq.conf

## Configure network
cat <<EOF > /etc/network/interfaces
auto wlan0
iface wlan0 inet static
    address 192.168.1.1
    netmask 255.255.255.0
EOF

## Configure network adapters in attica container
rm  /var/lib/lxc/attica/config
cat <<EOF >> /var/lib/lxc/attica/config
# Distribution configuration
lxc.include = /usr/share/lxc/config/common.conf
lxc.arch = linux64

# Container specific configuration
lxc.rootfs.path = dir:/var/lib/lxc/attica/rootfs
lxc.uts.name = attica

# Network configuration
lxc.net.0.type = veth
lxc.net.0.link = lxcbr0
lxc.net.0.flags = up
lxc.net.0.ipv4.address = "10.0.3.3/24"
lxc.net.1.type = phys
lxc.net.1.link = wlan2
lxc.net.1.flags = up
lxc.net.1.name = "wlan0"
lxc.start.delay = 1
EOF

## Autostart container at boot
cat <<EOF >> /etc/lxc/default.conf
lxc.start.auto = 1
EOF

## unmask hostapd
systemctl unmask hostapd
systemctl enable hostapd
systemctl start hostapd

## Start the client Container and install packages
lxc-start -n client -d
lxc-attach -n client -e -- sh -c "apt update; apt install -y tcpdump openssh-server wireless-tools libpcap-dev libusb-1.0-0-dev libnetfilter-queue-dev net-tools wpasupplicant rfkill"

## Configure network adapters in client container
rm /var/lib/lxc/client/config
cat <<EOF >> /var/lib/lxc/client/config
# Distribution configuration
lxc.include = /usr/share/lxc/config/common.conf
lxc.arch = linux64

# Container specific configuration
lxc.rootfs.path = dir:/var/lib/lxc/client/rootfs
lxc.uts.name = client

# Network configuration
lxc.net.1.type = phys
lxc.net.1.link = wlan1
lxc.net.1.flags = up
lxc.net.1.name = "wlan0"
lxc.start.delay = 1
EOF

lxc-stop client
lxc-start client

## Enable wpa supplicant
lxc-attach -n client -e -- sh -c "systemctl enable wpa_supplicant; systemctl start wpa_supplicant"

cat <<EOF > /var/lib/lxc/client/rootfs/etc/wpa_supplicant/wpa_supplicant.conf
ctrl_interface=/var/run/wpa_supplicant
network={
	ssid="HacktheWEPWifi"
    key_mgmt=NONE
    wep_key0=1A2B3C4D5E
    wep_tx_keyidx=0
}
EOF
chmod 0644 /var/lib/lxc/client/rootfs/etc/wpa_supplicant/wpa_supplicant.conf
chown root:root /var/lib/lxc/client/rootfs/etc/wpa_supplicant/wpa_supplicant.conf

## Copy wpa_supplicant.service
cat <<EOF > /var/lib/lxc/client/rootfs/etc/systemd/system/wpa_supplicant.service
[Unit]
Description=WPA supplicant
Before=network.target
After=dbus.service
Wants=network.target
IgnoreOnIsolate=true

[Service]
Type=dbus
BusName=fi.w1.wpa_supplicant1
ExecStart=/sbin/wpa_supplicant -u -s -c /etc/wpa_supplicant/wpa_supplicant.conf -i wlan0
Restart=always

[Install]
WantedBy=multi-user.target
EOF
chmod 0644 /var/lib/lxc/client/rootfs/etc/systemd/system/wpa_supplicant.service
chown root:root /var/lib/lxc/client/rootfs/etc/systemd/system/wpa_supplicant.service

## Copy dhclient.service
cat <<EOF > /var/lib/lxc/client/rootfs/etc/systemd/system/dhclient.service
[Unit]
Description=DHCP Client for client interface
Before=network.target

[Service]
Type=forking
ExecStart=/sbin/dhclient wlan0 -v
ExecStop=/sbin/dhclient wlan0 -r
Restart=always

[Install]
WantedBy=multi-user.target
EOF
chmod 0644 /var/lib/lxc/client/rootfs/etc/systemd/system/dhclient.service
chown root:root /var/lib/lxc/client/rootfs/etc/systemd/system/dhclient.service

## Enable dhclient
lxc-attach -n client -e -- sh -c "systemctl daemon-reload"
sleep 5
lxc-attach -n client -e -- sh -c "systemctl enable dhclient; systemctl restart dhclient; systemctl restart wpa_supplicant"

## Start the attica Container and configure
lxc-start -n attica -d
lxc-attach -n attica -e -- sh -c "apt update; apt install -y openssh-server tcpdump net-tools git wireless-tools aircrack-ng pciutils wpasupplicant reaver;"

## Add user to the container
lxc-attach -n attica -- useradd -m wifi
lxc-attach -n attica -- chpasswd <<< wifi:wifi
lxc-attach -n attica -e -- sh -c "sudo usermod -a -G sudo wifi"
## SSH forward
systemctl disable ssh
systemctl stop ssh
## Create Socat service to forward all SSH trafic to attica container
cat <<EOF > /etc/systemd/system/socat-forward.service
[Unit]
Description=Socat Port Forwarding Service
After=network.target

[Service]
ExecStart=/usr/bin/socat TCP-LISTEN:22,bind=0.0.0.0,fork TCP:10.0.3.3:22
Restart=always

[Install]
WantedBy=multi-user.target
EOF
## Install XFCE (Light weight desktop environment) inside WPAtomic container
lxc-attach -n attica -e -- sh -c "apt update -y; apt install -y xfce4 xfce4-goodies xrdp; echo 'xfce4-session' > /home/wifi/.xsession"
lxc-attach -n attica -e -- sh -c "apt install network-manager-gnome -y"
## Create Socat service to forward all RDP trafic to WPAtomic container
cat <<EOF > /etc/systemd/system/socat-forward-rdp.service
[Unit]
Description=Socat Port Forwarding Service
After=network.target
[Service]
ExecStart=/usr/bin/socat TCP-LISTEN:3389,bind=0.0.0.0,fork TCP:10.0.3.3:3389
Restart=always
[Install]
WantedBy=multi-user.target
EOF

## Set the background to a hack-the-box one
lxc-attach -n attica -e -- sh -c "wget https://github.com/ParrotSec/parrot-wallpapers/blob/master/backgrounds/hackthebox-alt.jpg?raw=truehttps://github.com/ParrotSec/parrot-wallpapers/blob/master/backgrounds/hackthebox-alt.jpg?raw=true -O /usr/share/backgrounds/xfce/xfce-verticals.png"
## Set shell to /bin/bash
lxc-attach -n attica -e -- sh -c "chsh -s /bin/bash wifi"

systemctl daemon-reload
systemctl restart socat-forward
systemctl restart socat-forward-rdp
systemctl enable dnsmasq
systemctl restart dnsmasq.service
systemctl enable socat-forward
systemctl enable socat-forward-rdp
ifdown wlan0 && ifup wlan0

## Configure Traffic generation service
cat <<EOF > /opt/traffic.sh
#!/bin/bash
sleep 15
lxc-attach -n client -e -- sh -c "while :; do ip neigh flush all dev wlan0; ping 192.168.1.1 -c 1; sleep 15; done"
EOF

chmod +x /opt/traffic.sh
cat <<EOF > /etc/systemd/system/traffic.service
[Unit]
Description=traffic for wireless simulation
After=network.target
[Service]
User=root
WorkingDirectory=/opt
ExecStart=/opt/traffic.sh
[Install]
WantedBy=multi-user.target
EOF

chmod +x /opt/traffic.sh
chmod 700 /etc/systemd/system/traffic.service
sudo systemctl daemon-reload
sudo systemctl start traffic
sudo systemctl enable traffic
